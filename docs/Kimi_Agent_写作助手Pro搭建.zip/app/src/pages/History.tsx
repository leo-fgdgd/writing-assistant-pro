import { useState } from 'react'
import { useNavigate } from 'react-router'
import { Search, Clock, Flame, Trash2, FileText, MessageSquare, Wand2 } from 'lucide-react'
import NavBar from '../components/NavBar'

interface HistoryProps {
  showToast: (message: string) => void
}

interface HistoryItem {
  id: number
  type: 'chat' | 'polish'
  title: string
  preview: string
  date: string
  tokens: string
}

const mockHistory: HistoryItem[] = [
  {
    id: 1,
    type: 'chat',
    title: '演讲稿：低碳生活',
    preview: '帮我写一份关于低碳生活的演讲稿，面向大学生群体，语气要有感染力...',
    date: '昨天 14:30',
    tokens: '1,240',
  },
  {
    id: 2,
    type: 'chat',
    title: '朋友圈文案：日出',
    preview: '写一篇朋友圈文案，关于周末去爬山看日出的经历，文艺一点...',
    date: '昨天 10:15',
    tokens: '386',
  },
  {
    id: 3,
    type: 'polish',
    title: '润色：季度报告',
    preview: '润色这段话：本季度销售额同比增长25%，主要得益于新产品线的推出...',
    date: '前天 16:45',
    tokens: '520',
  },
  {
    id: 4,
    type: 'chat',
    title: '短视频脚本：治愈',
    preview: '我想写一个短视频脚本，主题是"城市里的治愈瞬间"，时长约1分钟...',
    date: '3天前',
    tokens: '2,100',
  },
  {
    id: 5,
    type: 'chat',
    title: '商务邮件：方案介绍',
    preview: '请帮我写一封商务邮件，向客户介绍我们公司新推出的企业服务方案...',
    date: '4天前',
    tokens: '890',
  },
  {
    id: 6,
    type: 'polish',
    title: '改写：个人简历',
    preview: '帮我改写这段简历描述，突出数据驱动和用户体验设计能力...',
    date: '5天前',
    tokens: '450',
  },
  {
    id: 7,
    type: 'chat',
    title: '工作总结：Q2复盘',
    preview: '帮我写一份Q2季度工作总结，包括项目进展、团队协作和个人成长...',
    date: '6天前',
    tokens: '1,560',
  },
]

const typeIcons = {
  chat: MessageSquare,
  polish: Wand2,
}

const typeColors = {
  chat: '#E0A146',
  polish: '#3D5A42',
}

const typeLabels = {
  chat: '对话',
  polish: '润色',
}

export default function History({ showToast }: HistoryProps) {
  const navigate = useNavigate()
  const [searchQuery, setSearchQuery] = useState('')
  const [history, setHistory] = useState(mockHistory)
  const [filter, setFilter] = useState<'all' | 'chat' | 'polish'>('all')

  const filtered = history.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         item.preview.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesFilter = filter === 'all' || item.type === filter
    return matchesSearch && matchesFilter
  })

  const handleDelete = (id: number) => {
    setHistory(prev => prev.filter(item => item.id !== id))
    showToast('已删除')
  }

  return (
    <div className="min-h-screen" style={{ background: 'var(--page-bg)' }}>
      <NavBar title="历史记录" showBack />

      <div className="px-5 pt-4 pb-6">
        {/* Search Bar */}
        <div
          className="flex items-center gap-2 rounded-full px-4 h-10 mb-4"
          style={{
            background: '#FFFFFF',
            boxShadow: '0 1px 4px rgba(0,0,0,0.04)',
          }}
        >
          <Search size={18} color="#8E8E93" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="搜索历史记录..."
            className="flex-1 text-[14px] outline-none bg-transparent"
            style={{ color: 'var(--text-primary)' }}
          />
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2 mb-5">
          {[
            { key: 'all' as const, label: '全部' },
            { key: 'chat' as const, label: '对话' },
            { key: 'polish' as const, label: '润色' },
          ].map(({ key, label }) => (
            <button
              key={key}
              onClick={() => setFilter(key)}
              className="px-4 py-1.5 rounded-full text-[13px] font-medium transition-all"
              style={{
                background: filter === key ? '#1C1C1E' : '#FFFFFF',
                color: filter === key ? '#FFFFFF' : 'var(--text-secondary)',
                boxShadow: filter === key ? 'none' : '0 1px 4px rgba(0,0,0,0.04)',
              }}
            >
              {label}
            </button>
          ))}
        </div>

        {/* History List */}
        <div className="space-y-3">
          {filtered.map((item) => {
            const Icon = typeIcons[item.type]
            const color = typeColors[item.type]
            return (
              <div
                key={item.id}
                className="rounded-[16px] p-4 relative group"
                style={{
                  background: '#FFFFFF',
                  boxShadow: '0 1px 4px rgba(0,0,0,0.04)',
                }}
              >
                <button
                  onClick={() => navigate(item.type === 'chat' ? '/chat' : '/polish')}
                  className="w-full text-left"
                >
                  <div className="flex items-start gap-3">
                    <div
                      className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
                      style={{ background: `${color}15` }}
                    >
                      <Icon size={18} color={color} strokeWidth={1.5} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span
                          className="text-[15px] font-semibold truncate"
                          style={{ color: 'var(--text-primary)' }}
                        >
                          {item.title}
                        </span>
                        <span
                          className="text-[11px] px-2 py-0.5 rounded-full flex-shrink-0"
                          style={{
                            background: `${color}12`,
                            color,
                          }}
                        >
                          {typeLabels[item.type]}
                        </span>
                      </div>
                      <p
                        className="text-[13px] line-clamp-2 mb-2"
                        style={{
                          color: 'var(--text-secondary)',
                          lineHeight: 1.5,
                          display: '-webkit-box',
                          WebkitLineClamp: 2,
                          WebkitBoxOrient: 'vertical',
                          overflow: 'hidden',
                        }}
                      >
                        {item.preview}
                      </p>
                      <div className="flex items-center gap-3">
                        <span
                          className="flex items-center gap-1 text-[11px]"
                          style={{ color: 'var(--text-secondary)' }}
                        >
                          <Clock size={11} />
                          {item.date}
                        </span>
                        <span
                          className="flex items-center gap-1 text-[11px]"
                          style={{ color: 'var(--text-secondary)' }}
                        >
                          <Flame size={11} />
                          <span className="font-display">{item.tokens} tokens</span>
                        </span>
                      </div>
                    </div>
                  </div>
                </button>

                {/* Delete Button */}
                <button
                  onClick={() => handleDelete(item.id)}
                  className="absolute top-3 right-3 w-7 h-7 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                  style={{ background: '#F2F2F7' }}
                >
                  <Trash2 size={14} color="#FF3B30" />
                </button>
              </div>
            )
          })}
        </div>

        {filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20">
            <FileText size={48} color="#C7C7CC" strokeWidth={1} />
            <p className="text-[14px] mt-3" style={{ color: 'var(--text-secondary)' }}>
              暂无相关记录
            </p>
          </div>
        )}
      </div>
    </div>
  )
}
