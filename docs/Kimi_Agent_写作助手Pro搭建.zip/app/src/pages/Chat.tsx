import { useState, useRef, useEffect } from 'react'
import { useParams } from 'react-router'
import { Send, Copy, RotateCcw, Sparkles, Zap } from 'lucide-react'
import NavBar from '../components/NavBar'

interface ChatProps {
  showToast: (message: string) => void
}

interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: Date
}

const scenePrompts: Record<string, string> = {
  academic: '我需要写一篇学术论文的摘要部分，主题是人工智能在医疗诊断中的应用，请帮我梳理一个结构清晰的摘要框架。',
  business: '请帮我写一封商务邮件，向客户介绍我们公司新推出的企业服务方案，语气要专业且友好。',
  creative: '我想写一个短视频脚本，主题是"城市里的治愈瞬间"，时长约1分钟，需要有画面感和情感共鸣。',
  resume: '请帮我写一段简洁有力的个人简介，我是一名有5年经验的产品经理，想突出数据驱动和用户体验设计能力。',
}

const mockResponses: Record<string, string> = {
  academic: `好的，以下是为您的论文《人工智能在医疗诊断中的应用》梳理的摘要框架：

**一、研究背景**
随着深度学习技术的快速发展，人工智能在医疗影像分析、病理诊断等领域展现出巨大潜力...

**二、研究目的**
本研究旨在系统评估AI辅助诊断系统在不同科室的准确率与临床应用价值...

**三、研究方法**
采用多中心回顾性研究设计，收集了2019-2024年间10家三甲医院的数据...

**四、核心结论**
实验结果表明，AI辅助诊断在肺结节检测中的灵敏度达到96.3%，显著高于传统方法...

需要我针对某个部分展开详细写作吗？`,

  business: `主题：【新品发布】智云企业服务方案 —— 助力贵公司数字化转型

尊敬的 [客户姓名] 您好，

非常荣幸能与贵公司建立合作关系。我是 [公司名称] 的客户经理 [您的姓名]。

我们很高兴向您介绍全新升级的「智云企业服务方案」。该方案整合了云计算、大数据分析与企业级AI助手三大核心模块，专为中大型企业量身定制。

**方案亮点：**
• 部署周期缩短60%，最快7天即可上线
• 全链路数据加密，通过ISO 27001安全认证
• 7×24小时专属技术支持团队

不知您本周三或周四下午是否有30分钟时间？我可以安排一次线上演示，为您详细展示方案的核心功能。

期待您的回复！

此致
敬礼

[您的姓名]
[联系方式]`,

  creative: `**短视频脚本：《城市里的治愈瞬间》**
**时长：** 60秒
**风格：** 温暖/治愈/生活美学

---

**【0-5秒】开场**
画面：清晨第一缕阳光穿透窗帘，洒在木质书桌上。一杯冒着热气的咖啡，旁边是一本翻开的书。
字幕："每一天，城市都在悄悄准备惊喜"
BGM：轻柔的钢琴前奏

**【5-20秒】主线 - 三个治愈片段**

片段1：
画面：地铁上，一位老人颤巍巍地站着。旁边的年轻人默默起身让座，老人微笑着点头致谢。
字幕："善意，是流通的温暖"

片段2：
画面：下雨天，便利店门口摆着一排共享雨伞。一位女孩取走一把，第二天带回两把。
字幕："信任，是会生长的种子"

片段3：
画面：深夜加班的写字楼，外卖小哥送来热腾腾的夜宵。接过外卖时，发现袋子上画着笑脸。
字幕："温柔，是可以传递的力量"

**【20-50秒】高潮 - 蒙太奇混剪**
快速剪辑：街角花店店主精心包扎花束、公园长椅上情侣相视而笑、流浪猫被路人温柔投喂...
字幕："治愈不必远方，就在身边"

**【50-60秒】结尾**
画面：夜幕降临，城市灯火渐次亮起。镜头拉远，万家灯火构成一幅温暖的画卷。
字幕："你，也是别人的治愈瞬间"

---

需要我调整风格或补充分镜细节吗？`,

  resume: `以下是一段针对产品经理岗位优化的个人简介：

---

**个人简介**

拥有5年互联网产品经理经验，擅长以数据驱动产品决策、以用户为中心设计体验。曾主导3款DAU百万级产品的从0到1建设，累计创造营收超5000万。

**核心优势：**
• **数据驱动：** 精通SQL与Python数据分析，建立用户行为漏斗模型，将产品转化率提升40%
• **体验设计：** 主导用户研究体系搭建，完成200+场深度访谈，提炼核心痛点驱动产品迭代
• **跨团队协作：** 高效协调设计、研发、运营等多部门资源，平均项目交付周期缩短25%

**职业愿景：** 致力于用技术与设计的结合，创造真正解决用户痛点的产品。

---

需要我调整侧重点（偏数据/偏设计/偏管理）或控制字数吗？`,
}

const defaultResponse = `收到！我来帮您创作。

为了给您提供最精准的内容，能否补充几个细节：

1. **目标受众**是谁？（如：同事、客户、社交媒体粉丝）
2. **语气风格**偏好？（正式/轻松/文艺/专业）
3. **大致字数**要求？

或者，您可以直接告诉我主题，我会基于常见场景为您生成一版初稿！`

export default function Chat({ showToast }: ChatProps) {
  const { sceneId } = useParams<{ sceneId?: string }>()
  const [messages, setMessages] = useState<Message[]>([])
  const [inputValue, setInputValue] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  // Auto-send scene prompt if coming from scene card
  useEffect(() => {
    if (sceneId && scenePrompts[sceneId]) {
      const userMsg: Message = {
        id: Date.now().toString(),
        role: 'user',
        content: scenePrompts[sceneId],
        timestamp: new Date(),
      }
      setMessages([userMsg])
      setIsTyping(true)

      setTimeout(() => {
        const assistantMsg: Message = {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: mockResponses[sceneId] || defaultResponse,
          timestamp: new Date(),
        }
        setMessages(prev => [...prev, assistantMsg])
        setIsTyping(false)
      }, 1500)
    }
  }, [sceneId])

  const handleSend = () => {
    if (!inputValue.trim()) return

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue.trim(),
      timestamp: new Date(),
    }

    setMessages(prev => [...prev, userMsg])
    setInputValue('')
    setIsTyping(true)

    // Simulate AI response
    setTimeout(() => {
      const assistantMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: mockResponses['default'] || defaultResponse,
        timestamp: new Date(),
      }
      setMessages(prev => [...prev, assistantMsg])
      setIsTyping(false)
    }, 1200)
  }

  const handleCopy = (content: string) => {
    navigator.clipboard.writeText(content).catch(() => {})
    showToast('已复制到剪贴板')
  }

  const handleRegenerate = () => {
    showToast('重新生成中...')
    setIsTyping(true)
    setTimeout(() => {
      setIsTyping(false)
      showToast('生成完成')
    }, 1000)
  }

  const quickPrompts = [
    { icon: <Zap size={14} />, text: '写工作总结' },
    { icon: <Sparkles size={14} />, text: '朋友圈文案' },
    { icon: <Zap size={14} />, text: '演讲稿' },
    { icon: <Sparkles size={14} />, text: '短视频脚本' },
  ]

  return (
    <div className="flex flex-col" style={{ background: 'var(--page-bg)', minHeight: '100vh' }}>
      <NavBar title="语灵 AI" showBack />

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4 scrollbar-hide">
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 animate-fade-in">
            <div
              className="w-16 h-16 rounded-full flex items-center justify-center mb-4"
              style={{ background: 'rgba(224, 161, 70, 0.12)' }}
            >
              <Sparkles size={28} color="#E0A146" />
            </div>
            <h2
              className="text-[20px] font-semibold mb-2"
              style={{ color: 'var(--text-primary)' }}
            >
              语灵 AI 助手
            </h2>
            <p
              className="text-[14px] text-center mb-6"
              style={{ color: 'var(--text-secondary)' }}
            >
              告诉我你想写什么，我来帮你创作
            </p>
            <div className="flex flex-wrap gap-2 justify-center">
              {quickPrompts.map(({ icon, text }) => (
                <button
                  key={text}
                  onClick={() => {
                    setInputValue(`帮我${text}`)
                    inputRef.current?.focus()
                  }}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-full text-[13px]"
                  style={{
                    background: '#FFFFFF',
                    color: 'var(--text-primary)',
                    boxShadow: '0 1px 4px rgba(0,0,0,0.04)',
                    border: '1px solid #E5E5EA',
                  }}
                >
                  {icon}
                  {text}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex mb-4 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            {msg.role === 'assistant' && (
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center mr-2 flex-shrink-0 mt-1"
                style={{ background: 'rgba(224, 161, 70, 0.12)' }}
              >
                <Sparkles size={16} color="#E0A146" />
              </div>
            )}
            <div
              className="max-w-[80%] rounded-[18px] px-4 py-3 relative group"
              style={{
                background: msg.role === 'user' ? '#1C1C1E' : '#FFFFFF',
                color: msg.role === 'user' ? '#FFFFFF' : 'var(--text-primary)',
                fontSize: '15px',
                lineHeight: 1.75,
                boxShadow: msg.role === 'assistant' ? '0 1px 4px rgba(0,0,0,0.04)' : 'none',
                borderBottomLeftRadius: msg.role === 'assistant' ? '4px' : '18px',
                borderBottomRightRadius: msg.role === 'user' ? '4px' : '18px',
              }}
            >
              <div className="whitespace-pre-wrap">{msg.content}</div>

              {msg.role === 'assistant' && (
                <div className="flex items-center gap-2 mt-3 pt-2 opacity-0 group-hover:opacity-100 transition-opacity"
                  style={{ borderTop: '1px solid rgba(0,0,0,0.06)' }}
                >
                  <button
                    onClick={() => handleCopy(msg.content)}
                    className="flex items-center gap-1 text-[11px] px-2 py-1 rounded-md"
                    style={{ color: 'var(--text-secondary)' }}
                  >
                    <Copy size={12} />
                    复制
                  </button>
                  <button
                    onClick={handleRegenerate}
                    className="flex items-center gap-1 text-[11px] px-2 py-1 rounded-md"
                    style={{ color: 'var(--text-secondary)' }}
                  >
                    <RotateCcw size={12} />
                    重新生成
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex mb-4 justify-start">
            <div
              className="w-8 h-8 rounded-full flex items-center justify-center mr-2 flex-shrink-0"
              style={{ background: 'rgba(224, 161, 70, 0.12)' }}
            >
              <Sparkles size={16} color="#E0A146" />
            </div>
            <div
              className="rounded-[18px] px-4 py-3 flex items-center gap-1"
              style={{
                background: '#FFFFFF',
                borderBottomLeftRadius: '4px',
                boxShadow: '0 1px 4px rgba(0,0,0,0.04)',
              }}
            >
              <span className="w-2 h-2 rounded-full animate-typing" style={{ background: '#C7C7CC', animationDelay: '0ms' }} />
              <span className="w-2 h-2 rounded-full animate-typing" style={{ background: '#C7C7CC', animationDelay: '150ms' }} />
              <span className="w-2 h-2 rounded-full animate-typing" style={{ background: '#C7C7CC', animationDelay: '300ms' }} />
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div
        className="shrink-0 px-4 py-3"
        style={{
          background: 'rgba(255,255,255,0.92)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          borderTop: '1px solid #E5E5EA',
        }}
      >
        <div className="flex items-end gap-2">
          <textarea
            ref={inputRef}
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault()
                handleSend()
              }
            }}
            placeholder="输入你的写作需求..."
            rows={1}
            className="flex-1 resize-none rounded-[16px] px-4 py-3 text-[15px] outline-none max-h-[120px]"
            style={{
              background: '#F2F2F7',
              color: 'var(--text-primary)',
              lineHeight: 1.5,
            }}
          />
          <button
            onClick={handleSend}
            disabled={!inputValue.trim() || isTyping}
            className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 transition-all active:scale-95 disabled:opacity-40"
            style={{
              background: inputValue.trim() ? '#1C1C1E' : '#C7C7CC',
            }}
          >
            <Send size={18} color="#FFFFFF" />
          </button>
        </div>
      </div>
    </div>
  )
}
